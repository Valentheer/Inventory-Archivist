-- Optional manual scan control. Never triggers a replication scan automatically.
local IA=InventoryArchivistForever
local host,button,status
local elapsed=0
local function currentHost()
 if AuctionHouseFrame and AuctionHouseFrame:IsShown() then return AuctionHouseFrame end
 return nil
end
local function ageLabel(savedAt)
 if not savedAt or savedAt<=0 or not time then return 'unknown age' end
 local seconds=math.max(0,time()-savedAt)
 if seconds<60 then return 'just now' end
 if seconds<3600 then return math.floor(seconds/60)..'m ago' end
 if seconds<86400 then return math.floor(seconds/3600)..'h ago' end
 return math.floor(seconds/86400)..'d ago'
end
local function update()
 if not button then return end
 local api=IA.AHScan
 if not api then return end
 local s=api.Status()
 local pricing=IA.AHPrice and IA.AHPrice.Status and IA.AHPrice.Status()
 if pricing and pricing.working and not s.working and not s.armed then
  button:Enable();button:SetText('IA Scan Prices')
  status:SetText('Updating prices: '..pricing.processed..' / '..pricing.total)
 elseif s.working then
  button:Disable();button:SetText('Scanning...')
  status:SetText('Capturing '..s.captured..' / '..s.available)
 elseif s.armed then
  button:Disable();button:SetText('Waiting...')
  status:SetText('Waiting for AH replication data (server cooldown may apply)')
 else
  button:Enable();button:SetText('IA Scan Prices')
  if s.saved then status:SetText('Saved: '..s.saved..' listings ('..ageLabel(s.savedAt)..')')
  else status:SetText('No saved AH prices') end
 end
end
local function attach()
 local parent=currentHost()
 if not parent then if host then host:Hide() end;return end
 if not host then
  host=CreateFrame('Frame',nil,UIParent)
  host:SetSize(124,22)
  host:SetFrameStrata('DIALOG')
  host:SetFrameLevel(200)
  -- Anchor to the title bar, immediately left of the close button.
  -- Keep the native filters and the lower auction-house area unobstructed.
  host:SetPoint('TOPRIGHT',parent,'TOPRIGHT',-38,-1)
  button=CreateFrame('Button',nil,host,'UIPanelButtonTemplate')
  button:SetSize(124,20);button:SetPoint('TOPLEFT',0,0)
  button:SetFrameLevel(host:GetFrameLevel()+1)
  button:RegisterForClicks('LeftButtonUp')
  button:SetText('IA Scan Prices')
  button:SetScript('OnClick',function()
   if IA.AHScan then IA.AHScan.Request() end
   update()
  end)
  status=host:CreateFontString(nil,'OVERLAY','GameFontDisableSmall')
  -- Status lives in a hover tooltip so it does not cover the AH title or results.
  status:SetWidth(180);status:SetJustifyH('LEFT')
  button:SetScript('OnEnter',function(self)
   update()
   GameTooltip:SetOwner(self,'ANCHOR_BOTTOMLEFT')
   GameTooltip:AddLine('Inventory Archivist - AH Scan',1,0.82,0)
   GameTooltip:AddLine(status:GetText() or 'No scan status',1,1,1,true)
   GameTooltip:AddLine('Manual full scan; server cooldown may apply.',0.65,0.65,0.65,true)
   GameTooltip:Show()
  end)
  button:SetScript('OnLeave',function() GameTooltip:Hide() end)
 end
 -- UIParent parenting avoids custom AH children covering the button textures.
 -- Reanchor against the AH frame, retaining screen-relative placement.
 host:ClearAllPoints()
 host:SetPoint('TOPRIGHT',parent,'TOPRIGHT',-38,-1)
 host:Show();update()
end
local watcher=CreateFrame('Frame')
watcher:RegisterEvent('PLAYER_LOGIN')
watcher:RegisterEvent('AUCTION_HOUSE_SHOW')
watcher:RegisterEvent('AUCTION_HOUSE_CLOSED')
watcher:SetScript('OnEvent',function() attach() end)
watcher:SetScript('OnUpdate',function(_,dt)
 elapsed=elapsed+dt
 if elapsed<0.5 then return end
 elapsed=0
 if currentHost() then attach() elseif host and host:IsShown() then host:Hide() end
end)
