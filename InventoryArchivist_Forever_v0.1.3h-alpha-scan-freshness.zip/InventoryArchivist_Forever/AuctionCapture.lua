-- Diagnostic AH snapshot capture for WoW Forever. No auction posting or purchasing.
-- Captures the replication result while the AH is open into per-realm SavedVariables.
local IA=InventoryArchivistForever
local MAX_RECORDS=100000
local FIELDS=20
local BATCH=300
local f=CreateFrame('Frame')
local working=nil
local captureArmed=false -- one requested capture per scan/capture command
local lastProgress=0
local requestStarted=nil
local WAIT_TIMEOUT=35 -- local UI timeout only; not a claim about server cooldown
local function say(s) IA.Notify('AH: '..s) end
local function bucket()
 local id=IA.RealmID()
 if not id then return nil end
 local db=InventoryArchivistForeverDB
 db.ahSnapshots=db.ahSnapshots or {}
 db.ahSnapshots[id]=db.ahSnapshots[id] or {}
 return db.ahSnapshots[id]
end
local function ah() return C_AuctionHouse end
local function count()
 local a=ah()
 if not a or type(a.GetNumReplicateItems)~='function' then return 0 end
 local ok,n=pcall(a.GetNumReplicateItems)
 return ok and type(n)=='number' and n or 0
end
local function finish(reason)
 if not working then return end
 local b=bucket()
 if b then
  b.latest=working.data
  b.latest.savedAt=time and time() or 0
  b.latest.status=reason
 end
 local complete=(reason=='complete' or reason:match('^capped at '))
 say('Saved '..working.data.captured..'/'..working.data.available..' records ('..reason..'). Use /reload or logout to write SavedVariables to disk.')
 working=nil
 requestStarted=nil
 f:SetScript('OnUpdate',nil)
 -- The analyzer is loaded later in the TOC. Resolve it at completion time.
 -- Partial captures are intentionally not auto-analyzed.
 if complete and IA.AHPrice and IA.AHPrice.Analyze then
  IA.AHPrice.Analyze(true)
 elseif not complete then
  say('Capture incomplete; automatic price refresh skipped.')
 end
end
local function begin()
 if working or not captureArmed then return end
 local a=ah()
 local n=count()
 if n<1 then return end
 if not bucket() then captureArmed=false;say('No realm ID; refusing to store cross-realm data.');return end
 local data={schema=1,realm=IA.RealmName(),startedAt=time and time() or 0,available=n,captured=0,records={},sampleLinks={},status='capturing'}
 captureArmed=false -- consume authorization BEFORE any further replication events
 requestStarted=nil
 working={data=data,index=1,limit=math.min(n,MAX_RECORDS)}
 lastProgress=0
 say('Replication ready: '..n..' records. Capturing in batches; keep the AH open until complete.')
 f:SetScript('OnUpdate',function()
  local w=working
  if not w then return end
  local api=ah()
  if count()==0 then finish('partial: client data cleared');return end
  local stop=math.min(w.index+BATCH-1,w.limit)
  for i=w.index,stop do
   -- Explicit select() preserves holes in the multi-return tuple, unlike { ... } + #.
   local ok,values=pcall(function()
    local r={n=select('#',api.GetReplicateItemInfo(i)),api.GetReplicateItemInfo(i)}
    return r
   end)
   if ok and values then
    local compact={}
    for j=1,math.min(values.n,FIELDS) do
     local v=values[j]
     if type(v)=='number' or type(v)=='boolean' then compact[j]=v
     elseif type(v)=='string' then compact[j]=v:sub(1,350) end
    end
    w.data.records[i]=compact
    if i<=15 and type(api.GetReplicateItemLink)=='function' then
     local linkOK,link=pcall(api.GetReplicateItemLink,i)
     if linkOK and type(link)=='string' then w.data.sampleLinks[i]=link end
    end
   else
    w.data.records[i]={error=true}
   end
   w.data.captured=i
  end
  w.index=stop+1
  if w.data.captured-lastProgress>=10000 then lastProgress=w.data.captured;say('Captured '..w.data.captured..'/'..w.data.available) end
  if w.index>w.limit then finish(n>MAX_RECORDS and 'capped at '..MAX_RECORDS or 'complete') end
 end)
end
f:RegisterEvent('REPLICATE_ITEM_LIST_UPDATE')
f:RegisterEvent('AUCTION_HOUSE_CLOSED')
f:SetScript('OnEvent',function(_,event) if event=='AUCTION_HOUSE_CLOSED' then captureArmed=false;requestStarted=nil else begin() end end)
IA.AHScan={}
function IA.AHScan.Status()
 local b=bucket();local d=b and b.latest
 return {working=working~=nil,armed=captureArmed,captured=working and working.data.captured or 0,available=working and working.data.available or 0,saved=d and d.captured or nil,savedAt=d and d.savedAt or nil,saveStatus=d and d.status or nil}
end
function IA.AHScan.Request()
 local a=ah()
 if not a or type(a.ReplicateItems)~='function' then say('Replication API unavailable.');return end
 if not (AuctionHouseFrame and AuctionHouseFrame:IsShown()) then say('Open the Auction House first.');return end
 if working then say('Capture already in progress.');return end
 if captureArmed then say('Already waiting for replication data.');return end
 captureArmed=true
 requestStarted=GetTime and GetTime() or nil
 if count()>0 then say('Existing replication data detected; capturing without a new request.');begin();return end
 local ok,err=pcall(a.ReplicateItems)
 if ok then say('Full scan requested. This does not confirm server acceptance; wait for the completion event.')
 else captureArmed=false;requestStarted=nil;say('Scan request failed: '..tostring(err)) end
end
-- Clear a stalled waiting state if the server never returns a replication event.
-- Does not imply a known server cooldown or alter saved auction data.
local timeoutFrame=CreateFrame('Frame')
local tick=0
timeoutFrame:SetScript('OnUpdate',function(_,dt)
 if not captureArmed or not requestStarted or not GetTime then return end
 tick=tick+dt
 if tick<1 then return end
 tick=0
 if GetTime()-requestStarted>=WAIT_TIMEOUT then
  captureArmed=false;requestStarted=nil
  say('No replication response after '..WAIT_TIMEOUT..'s. Request may be on cooldown; saved prices are unchanged. Try again later.')
 end
end)
local function command(msg)
 msg=(msg or ''):lower():match('^%s*(.-)%s*$')
 if msg=='scan' then
  IA.AHScan.Request() elseif msg=='capture' then
  if count()>0 then captureArmed=true;begin() else say('No replication data available. Open AH and use /iaah scan when eligible.') end
 elseif msg=='status' then
  local b=bucket();local d=b and b.latest
  say('Client records: '..count()..'; capturing: '..(working and (working.data.captured..'/'..working.data.available) or 'no'))
  if d then say('Saved: '..tostring(d.captured)..'/'..tostring(d.available)..' ('..tostring(d.status)..'), realm '..tostring(d.realm)..', timestamp '..tostring(d.savedAt)) else say('No saved snapshot for this realm.') end
 elseif msg=='sample' then
  local b=bucket();local d=b and b.latest
  if not d then say('No completed snapshot yet.');return end
  for i=1,math.min(3,d.captured or 0) do
   local r=d.records[i] or {};local out={}
   for j=1,FIELDS do if r[j]~=nil then out[#out+1]=j..'='..tostring(r[j]):sub(1,35) end end
   say('Record '..i..': '..table.concat(out,' | '):sub(1,220))
  end
 elseif msg=='help' or msg=='' then
  say('Commands: /iaah scan, /iaah capture, /iaah status, /iaah sample. Snapshot persists to disk at /reload or logout.')
 else say('Unknown command. /iaah help') end
end
SLASH_IAAH1='/iaah'
SlashCmdList.IAAH=command
