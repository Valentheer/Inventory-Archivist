-- Inventory Archivist Forever: experimental read-only snapshot price analysis.
-- The captured replication field 10 is treated as a candidate TOTAL buyout,
-- pending cross-check against live AH prices. No posting or purchasing actions.
local IA=InventoryArchivistForever
local state=nil
local FRAME_BATCH=500
local f=CreateFrame('Frame')
local function say(s) IA.Notify('AH Price: '..s) end
local function snapshot()
 local id=IA.RealmID()
 local b=id and InventoryArchivistForeverDB.ahSnapshots and InventoryArchivistForeverDB.ahSnapshots[id]
 return b and b.latest,id
end
local function money(c)
 c=math.floor((c or 0)+0.5)
 local g=math.floor(c/10000);local s=math.floor(c%10000/100);local cp=c%100
 if g>0 then return g..'g '..s..'s '..cp..'c' end
 if s>0 then return s..'s '..cp..'c' end
 return cp..'c'
end
local function median(a,weighted)
 if #a==0 then return nil end
 table.sort(a,function(x,y) return x.p<y.p end)
 if not weighted then
  local n=#a
  if n%2==1 then return a[(n+1)/2].p end
  return (a[n/2].p+a[n/2+1].p)/2
 end
 local total=0
 for _,x in ipairs(a) do total=total+x.q end
 local target=total/2;local cumul=0
 for _,x in ipairs(a) do cumul=cumul+x.q;if cumul>=target then return x.p end end
 return a[#a].p
end
local function compute(g)
 local arr=g.levels
 table.sort(arr,function(a,b) return a.p<b.p end)
 g.minimum=arr[1] and arr[1].p or nil
 g.listingMedian=median(arr,false)
 g.market=median(arr,true)
 g.levelSummary={}
 for _,x in ipairs(arr) do
  local prev=g.levelSummary[#g.levelSummary]
  -- Copper-level grouping; avoid rounding floating point prices to integer until display.
  local price=math.floor(x.p+0.5)
  if prev and prev.price==price then prev.units=prev.units+x.q;prev.listings=prev.listings+1
  else g.levelSummary[#g.levelSummary+1]={price=price,units=x.q,listings=1} end
 end
 g.levels=nil -- summary remains compact; raw snapshot retained separately
end
local function begin(automatic)
 if state then if not automatic then say('Analysis already running.') end;return false end
 local d,id=snapshot()
 if not d or type(d.records)~='table' then say('No saved snapshot for this realm.');return false end
 local n=tonumber(d.captured) or tonumber(d.available) or 0
 if n<1 then say('Snapshot has no records.');return false end
 local result={schema=1,sourceSavedAt=d.savedAt or 0,realm=d.realm,sourceCaptured=n,groups={},byID={},valid=0,skipped=0,missing=0}
 state={source=d,result=result,index=1,limit=n,realmID=id}
 say((automatic and 'Automatically refreshing prices from ' or 'Analyzing ')..n..' saved records.')
 f:SetScript('OnUpdate',function()
  local w=state;if not w then return end
  local stop=math.min(w.index+FRAME_BATCH-1,w.limit)
  for i=w.index,stop do
   local r=w.source.records[i]
   local name=r and r[1];local idn=r and tonumber(r[17]);local qty=r and tonumber(r[3]);local total=r and tonumber(r[10])
   if type(name)=='string' and name~='' and idn and idn>0 and qty and qty>0 and total and total>0 and r[18]~=false then
    -- Keep differently named random-enchantment variants apart.
    local key=tostring(idn)..'|'..name
    local g=w.result.groups[key]
    if not g then
     g={id=idn,name=name,listings=0,units=0,levels={}}
     w.result.groups[key]=g
     local ids=w.result.byID[idn] or {};w.result.byID[idn]=ids;ids[#ids+1]=key
    end
    g.listings=g.listings+1;g.units=g.units+qty
    g.levels[#g.levels+1]={p=total/qty,q=qty}
    w.result.valid=w.result.valid+1
   else
    w.result.skipped=w.result.skipped+1
    if not r or type(name)~='string' or name=='' then w.result.missing=w.result.missing+1 end
   end
  end
  w.index=stop+1
  if w.index>w.limit then
   local nGroups=0
   for _,g in pairs(w.result.groups) do compute(g);nGroups=nGroups+1 end
   w.result.groupCount=nGroups
   local db=InventoryArchivistForeverDB
   db.ahPriceSummaries=db.ahPriceSummaries or {}
   db.ahPriceSummaries[w.realmID]=w.result
   state=nil;f:SetScript('OnUpdate',nil)
   say('Done: '..w.result.valid..' valid listings; '..w.result.skipped..' skipped ('..w.result.missing..' unnamed); '..nGroups..' item/name groups.')
   say('Vault pricing is now refreshed for this realm.')
  end
 end)
 return true
end
IA.AHPrice={Analyze=begin,Status=function() return {working=state~=nil,processed=state and (state.index-1) or 0,total=state and state.limit or 0} end}
local function saved()
 local id=IA.RealmID()
 return id and InventoryArchivistForeverDB.ahPriceSummaries and InventoryArchivistForeverDB.ahPriceSummaries[id]
end
local function age(t)
 local now=time and time() or 0
 if not t or t<=0 or now<t then return 'unknown' end
 local h=math.floor((now-t)/3600)
 if h<1 then return math.floor((now-t)/60)..'m' end
 if h<48 then return h..'h' end
 return math.floor(h/24)..'d '..(h%24)..'h'
end
local function lookup(arg,showLevels)
 local s=saved();if not s then say('No analysis yet. Run /iaah analyze.');return end
 local id=tonumber(arg)
 if not id then say('Use an item ID, e.g. /iaah price 2449');return end
 local keys=s.byID[id]
 if not keys or #keys==0 then say('No valid buyout records for item '..id..'.');return end
 if #keys>1 then say('Item '..id..' has '..#keys..' named variants; prices are NOT combined. Showing up to 5:') end
 for i=1,math.min(#keys,5) do
  local g=s.groups[keys[i]]
  if g then
   say(g.name..' ['..id..']: '..g.listings..' listings / '..g.units..' units; snapshot '..age(s.sourceSavedAt)..' old')
   if showLevels then
    for j=1,math.min(5,#g.levelSummary) do
     local l=g.levelSummary[j]
     say('  '..money(l.price)..'/unit: '..l.units..' units ('..l.listings..' listings)')
    end
   else
    say('  Market estimate (unit-weighted median): '..money(g.market)..'/unit; lowest: '..money(g.minimum)..'/unit')
    say('  Listing median (diagnostic): '..money(g.listingMedian)..'/unit')
   end
  end
 end
 if #keys>5 then say('...additional variants omitted.') end
end
local function stats()
 local s=saved();if not s then say('No analysis yet. Run /iaah analyze.');return end
 say('Realm '..tostring(s.realm)..'; snapshot '..age(s.sourceSavedAt)..' old; '..s.sourceCaptured..' source records.')
 say(s.valid..' valid listings; '..s.skipped..' skipped ('..s.missing..' unnamed); '..s.groupCount..' item/name groups.')
 say('Price interpretation: field 10 = candidate total buyout; verify against AH. Equipment modifiers may be incomplete.')
end
-- Add diagnostic commands without altering existing /iaah capture command handler.
SLASH_IAAHPRICE1='/iaahprice'
SlashCmdList.IAAHPRICE=function(msg)
 local cmd,arg=(msg or ''):lower():match('^%s*(%S+)%s*(.-)%s*$')
 if cmd=='analyze' then begin()
 elseif cmd=='price' then lookup(arg,false)
 elseif cmd=='levels' then lookup(arg,true)
 elseif cmd=='stats' then stats()
 else say('Commands: /iaahprice analyze | price ITEMID | levels ITEMID | stats') end
end
-- Expose read-only data for future Vault tooltip integration.
InventoryArchivistAHPrices={Get=function(itemID)
 local s=saved();local keys=s and s.byID[tonumber(itemID)]
 if not keys or #keys~=1 then return nil end
 return s.groups[keys[1]],s.sourceSavedAt
end}
