## v0.1.3h-alpha — Scan freshness and waiting feedback
- Scan button aligned to (-38, -1).
- Button tooltip shows saved snapshot age.
- Waiting requests time out after 35 seconds without a replication response; existing saved snapshot remains untouched.
- Server cooldown is not directly measured.

## v0.1.3e1-alpha — AH tooltip onboarding
- When AH tooltip options are enabled but this realm has no saved AH snapshot, Vault item tooltips explain how to scan and where to disable AH tooltips.
- Once a snapshot exists, unpriced items continue to show no AH section.
- All three AH settings off still hides the entire AH section.
- No changes to capture or pricing calculation.

## v0.1.3e-alpha — Vault AH tooltip pricing
- Added optional Market estimate (quantity-weighted median), Lowest listing, and Estimated owned value to Vault item tooltips.
- Added three independent Settings checkboxes; disabling all removes the AH tooltip section entirely.
- Valuation respects selected View/Exclude inventory quantity.
- Uses existing analyzed realm snapshot; no new AH scan required.
- Ambiguous equipment variants and missing price groups do not show misleading valuations.
- Retains v0.1.3d analyzer and v0.1.3c capture event guard.

# Changelog

## 0.1.2j-alpha — Community testing package
- Fresh installations default to custom bag positioning enabled, locked, and position controls always visible.
- Existing user preferences are preserved.
- Previous alpha work stabilized combined/separate bag positioning, keyring and reagent bag handling, saved coordinates, and reset behavior.
- Refined native-style lock control and title-bar spacing.
- Public-package housekeeping: removed development-note files, refreshed version message and metadata, added documentation.

### Known minor issue
- A natively stacked bag may briefly follow another bag during drag before snapping back to its saved location.

## 0.1.3d-alpha — Pricing diagnostics
- Added non-destructive, batched analysis of existing AH snapshot.
- Added /iaahprice analyze, price, levels, stats.
- Retained original capture and Vault functionality.

- v0.1.3f1: Relocated manual AH scan button to top-right title bar; scan status now appears on button hover to avoid obscuring AH controls.

## v0.1.3h-alpha — Automatic AH pricing refresh
- After a successful full replication capture, automatically recompute realm price summaries in batches.
- Vault tooltip values update from the new summary without a manual analyze command.
- Partial captures do not trigger automatic analysis.
- AH scan button tooltip shows pricing analysis progress.
- Preserves the user-tested -2 title bar vertical offset.
