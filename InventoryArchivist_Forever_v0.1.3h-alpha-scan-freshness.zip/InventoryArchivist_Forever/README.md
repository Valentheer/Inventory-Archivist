# Inventory Archivist — Forever

**Version:** 0.1.2j-alpha (community test release)  
**Client:** WoW Forever 1.60.1 (Interface 16001)

Inventory Archivist is a community-made addon for tracking character inventories, viewing account-wide item snapshots through its Vault, and customizing bag positions in WoW Forever.

## Install

1. Exit the game.
2. Extract the ZIP into your WoW Forever `Interface/AddOns/` directory.
3. Confirm the result is `Interface/AddOns/InventoryArchivist_Forever/InventoryArchivist_Forever.toc` (not a nested duplicate folder).
4. Launch the game and enable **Inventory Archivist - Forever** if needed.
5. Type `/ia` to open the Vault; `/ia status` shows diagnostics.

## Features

- Locally recorded character inventory and bank snapshots, separated by realm.
- Read-only Account Vault for viewing tracked items across characters.
- Bag and bank inventory markers.
- Custom bag positioning with independent combined/separate layouts, reset controls, and saved coordinates.
- New-install defaults: positioning enabled, locked, and controls always visible. Existing settings are retained on update.

## Alpha feedback

Please share: (1) what happened, (2) exact steps to reproduce, (3) Lua errors if any, (4) screenshot if helpful, and (5) whether `/reload` changes the behavior. Particularly useful: combined/separate bag switching, keyring/reagent behavior, bank markers, and realm isolation.

Known minor visual quirk: when dragging a bag with other bags natively stacked against it, an attached bag can briefly follow and snap back to its saved position. This does not normally change saved positions.

## Data and updates

The addon stores snapshots and preferences locally using WoW SavedVariables (`InventoryArchivistForeverDB`). Back up the relevant SavedVariables files before major testing. Installing a new ZIP normally preserves existing saved data.

This addon does not move, delete, sell, or modify inventory items. This is an independent community project and is not affiliated with Blizzard Entertainment or the WoW Forever team.

## License

The project's original source code is intended to be distributed under the MIT License. **Before redistributing this ZIP, place your completed `LICENSE` file inside the `InventoryArchivist_Forever` folder.** The `LICENSE` file is intentionally not included in this package because the copyright-holder details were not supplied for packaging. Blizzard trademarks, game assets, and any third-party components remain subject to their respective owners' terms.


## v0.1.3d experimental AH price analyzer

Existing /iaah scan/capture/status/sample commands are unchanged. To analyze a
previously captured snapshot (without scanning the AH again), use:

- `/iaahprice analyze` — calculate saved price summaries in small frame batches.
- `/iaahprice price 2449` — display market estimate and lowest unit price.
- `/iaahprice levels 2449` — show five cheapest unit-price levels.
- `/iaahprice stats` — show analysis totals and snapshot age.

The price estimator uses the quantity-weighted median of per-unit listing
prices; the lowest listing is also displayed. Both are *asking-price* estimates,
not completed sales. Field 10 of the replication tuple is provisionally
interpreted as total buyout; compare against the AH before relying on values.

Analysis is read-only, realm-scoped, and keeps the original raw snapshot.
Different item names sharing an ID are NOT mixed; equipment variant data is
not yet fully captured. No Vault UI or tooltip pricing changes in this test.

Note: The pricing diagnostics use `/iaahprice` (not `/iaah`) to avoid changing
the proven snapshot capture command handler during this test.

### Experimental Vault AH pricing (v0.1.3e)
Run `/iaahprice analyze` once on a realm with a saved AH replication snapshot.
Hover an item in the Account Vault to see optional market estimate, lowest listing, and estimated owned value.
Each line can be disabled independently under `/ia settings`; disabling all three removes the AH section.
Prices are snapshot-based asking prices, not guaranteed sale proceeds. For item IDs with multiple named equipment variants, no price is shown until variant-safe lookup is available.

### New-player AH tooltip hint (v0.1.3e1)
When at least one AH tooltip option is enabled and the current realm has no saved AH snapshot, Vault item tooltips show a brief hint to visit the AH and run `/iaah scan`, or disable AH tooltip options in `/ia settings`. The hint disappears once a snapshot exists; unpriced items remain silent.
